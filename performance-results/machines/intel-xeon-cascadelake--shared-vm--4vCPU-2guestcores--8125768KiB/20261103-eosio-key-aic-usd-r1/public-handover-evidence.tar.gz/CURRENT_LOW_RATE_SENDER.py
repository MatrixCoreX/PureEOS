from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import ast,datetime,hashlib,json,random,subprocess,time,traceback,urllib.request,urllib.error
E=Path('/opt/pureeos-test45-20261102-r1');A=E/'activity';V=E/'voting';B=E;T=B/'pureeos-test-1.0.0-test.1/bin';W=A/'wallet';Q=json.loads((A/'QUALIFIED.json').read_text());PLAN=json.loads((V/'PLAN.json').read_text());CHAIN=PLAN['chain_id'];ACTORS=[v['name']for v in PLAN['voters']];PASSWORD=(W/'password.txt').read_text().strip();BASE=[str(T/'cleos'),'--no-auto-keosd','--url','http://127.0.0.1:51003','--wallet-url','unix://'+str(W/'keosd.sock')]
assert Q['status']=='PASS'and Q['signing_wallet_ordinary_keys_only']and len(ACTORS)==90
SEED=hashlib.sha256((CHAIN+'|ordinary-sparse-business|20261102-r1').encode()).hexdigest();rng=random.Random(int(SEED,16));SOURCE=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,data):
 p=A/(path+'.pending');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(A/path)
def log(path,data):
 with(A/path).open('a')as f:f.write(json.dumps(data)+'\n')
def rpc(method,data={}):
 assert method.startswith('get_')
 for attempt in range(4):
  try:
   with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:51003/v1/chain/'+method,json.dumps(data).encode(),{'Content-Type':'application/json'}),timeout=10)as r:return json.load(r)
  except (urllib.error.URLError,TimeoutError,ConnectionError)as error:
   body=error.read().decode(errors='replace')if isinstance(error,urllib.error.HTTPError)else str(error);log('READ_RETRIES.jsonl',{'UTC':now(),'method':method,'attempt':attempt+1,'error':str(error),'body':body})
   if isinstance(error,urllib.error.HTTPError)and error.code not in [500,502,503,504]:raise
   if attempt==3:raise
   time.sleep(.5*(attempt+1))
def cli(args,input=None,allow=False):
 r=subprocess.run(BASE+args,input=input,text=True,capture_output=True,timeout=60)
 if r.returncode and not allow:raise RuntimeError((r.stdout+r.stderr).replace(PASSWORD,'<redacted>')[-2500:])
 return r

def cash(name):
 values=rpc('get_currency_balance',{'code':'eosio.token','account':name,'symbol':'AIC'})
 if not values:return 0
 quantity,symbol=values[0].split();assert symbol=='AIC'and len(quantity.split('.')[1])==4;return int(quantity.replace('.',''))
def counter_nonce(name):
 rows=rpc('get_table_rows',{'code':'civiccounter','scope':'civiccounter','table':'counters','json':True,'key_type':'name','lower_bound':name,'limit':1})['rows'];return int(rows[0]['nonce'])if rows and rows[0]['owner']==name else 0
S=json.loads((A/'STATE.json').read_text())if(A/'STATE.json').exists()else{'status':'INITIALIZING','version':1,'chain_id':CHAIN,'started_UTC':now(),'completed_batches':0,'business_transactions':0,'transfers':0,'ticks':0,'notes':0,'empty_blocks':0,'empty_block_samples':[],'batch_sizes':{},'max_chain_receipts_in_observed_batch_block':0,'pending':None,'balances':{},'source_history':[]}
assert S['chain_id']==CHAIN
if S.get('random_state'):rng.setstate(ast.literal_eval(S['random_state']))
if not S['source_history']or S['source_history'][-1]['SHA256']!=SOURCE:S['source_history'].append({'UTC':now(),'SHA256':SOURCE})
def save():S.update(UTC=now(),random_state=repr(rng.getstate()));write('STATE.json',S)
def broadcast(item):
 for attempt in range(3):
  try:
   with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:51003/v1/chain/push_transaction',json.dumps(item['packed']).encode(),{'Content-Type':'application/json'}),timeout=10)as r:out=json.load(r)
   assert out['transaction_id']==item['id'];assert out['processed']['receipt']['status']=='executed';return{'id':item['id'],'status':'accepted'}
  except urllib.error.HTTPError as error:
   body=error.read().decode(errors='replace')
   if 'tx_duplicate'in body or 'duplicate transaction'in body.lower():return{'id':item['id'],'status':'already_known'}
   return{'id':item['id'],'status':'rejected','error':body[-3000:]}
  except (urllib.error.URLError,TimeoutError,ConnectionError)as error:
   # Reuse EXACT signed packet/transaction ID; never generate a new payment
   # to compensate for an ambiguous network response.
   if attempt==2:return{'id':item['id'],'status':'uncertain','error':str(error)}
   time.sleep(.5)
def make_batch():
 info=rpc('get_info');assert info['chain_id']==CHAIN;bid=bytes.fromhex(info['last_irreversible_block_id']);expiration=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=1800)).strftime('%Y-%m-%dT%H:%M:%S');size=rng.randint(1,3);actors=rng.sample(ACTORS,size);packets=[];batch_id=S['completed_batches']+1
 cli(['wallet','unlock','-n','activity-demo'],PASSWORD+'\n',allow=True)
 for actor in actors:
  if rng.randrange(10)==0:
   kind=rng.choice(['tick','note']);data={'user':actor,'nonce':counter_nonce(actor)+1}
   if kind=='tick':data['delta']=rng.randint(1,20)
   else:data['memo']=rng.choice(['Compute allocation','Storage allocation','Service request','Daily note'])+' '+str(batch_id)
   contract='civiccounter';meta={'kind':kind,'actor':actor,'nonce':data['nonce']}
  else:
   kind='transfer';target=rng.choice([v for v in ACTORS if v!=actor]);available=S['balances'][actor]
   assert available>0,'Ordinary sender balance exhausted';quantity=rng.randint(1,min(100,available));data={'from':actor,'to':target,'quantity':str(quantity//10000)+'.'+str(quantity%10000).zfill(4)+' AIC','memo':rng.choice(['Compute credits','Storage share','Service tip','Daily transfer'])+' '+str(batch_id)};contract='eosio.token';meta={'kind':kind,'actor':actor,'to':target,'quantity_smallest_units':quantity}
  action={'account':contract,'name':kind,'authorization':[{'actor':actor,'permission':'active'}],'data':data}
  assert actor in ACTORS and contract in ['eosio.token','civiccounter']
  tx={'expiration':expiration,'ref_block_num':info['last_irreversible_block_num']&65535,'ref_block_prefix':int.from_bytes(bid[8:12],'little'),'max_net_usage_words':0,'max_cpu_usage_ms':0,'delay_sec':0,'context_free_actions':[],'actions':[action],'transaction_extensions':[]}
  packed=json.loads(cli(['push','transaction',json.dumps(tx),'-d','--expiration','1800','--return-packed','-j']).stdout);assert packed.get('compression')in ['none',0]and packed.get('signatures');tid=hashlib.sha256(bytes.fromhex(packed['packed_trx'])).hexdigest();packets.append({'id':tid,'packed':packed,'action':action,'metadata':meta})
 return {'batch':batch_id,'created_UTC':now(),'planned_size':size,'cursor':info['last_irreversible_block_num']+1,'receipts':{},'packets':packets,'broadcasts':[],'source_SHA256':SOURCE}
def finish_batch(p):
 missing={v['id']for v in p['packets']} - set(p['receipts'])
 if missing:
  time.sleep(max(0,S.get('next_broadcast_not_before_unix',0)-time.time()));S['next_broadcast_not_before_unix']=time.time()+30;save()
  with ThreadPoolExecutor(max_workers=4)as pool:sent=list(pool.map(broadcast,[v for v in p['packets']if v['id']in missing]))
  p['broadcasts'].extend(sent);save();rejected=[v for v in sent if v['status']=='rejected']
  if rejected:log('REJECTED_BATCHES.jsonl',{'UTC':now(),'batch':p['batch'],'rejected':rejected});raise RuntimeError('Business transaction rejected; pending evidence retained')
 end=time.monotonic()+180
 while missing:
  info=rpc('get_info');assert info['chain_id']==CHAIN;lib=info['last_irreversible_block_num']
  while p['cursor']<=lib:
   n=p['cursor'];b=rpc('get_block',{'block_num_or_id':n})
   for receipt in b['transactions']:
    tid=receipt['trx']if isinstance(receipt['trx'],str)else receipt['trx']['id']
    if tid in missing:
     assert receipt['status']=='executed';p['receipts'][tid]={'height':n,'id':b['id'],'timestamp':b['timestamp'],'receipt_status':receipt['status'],'whole_block_receipt_count':len(b['transactions'])};missing.remove(tid)
   p['cursor']+=1
  save();assert time.monotonic()<end,'Timed out waiting for finalized activity; never resend as new payments'
  if missing:time.sleep(.25)
 assert len(p['receipts'])==p['planned_size']and 1<=p['planned_size']<=20
 for item in p['packets']:
  m=item['metadata'];S['business_transactions']+=1
  if m['kind']=='transfer':S['transfers']+=1;S['balances'][m['actor']]-=m['quantity_smallest_units'];S['balances'][m['to']]+=m['quantity_smallest_units']
  elif m['kind']=='tick':S['ticks']+=1
  else:S['notes']+=1
  S['max_chain_receipts_in_observed_batch_block']=max(S['max_chain_receipts_in_observed_batch_block'],p['receipts'][item['id']]['whole_block_receipt_count'])
 assert sum(S['balances'].values())==S['initial_ordinary_liquid_total_smallest_units']and min(S['balances'].values())>=0
 S['completed_batches']+=1;key=str(p['planned_size']);S['batch_sizes'][key]=S['batch_sizes'].get(key,0)+1
 record={k:p[k]for k in ['batch','created_UTC','planned_size','receipts','source_SHA256']};record['expiry_recovery']=p.get('expiry_recovery');record['finalized_UTC']=now();record['transactions']=[{'id':v['id'],'metadata':v['metadata'],'action':v['action']}for v in p['packets']];S['last_completed_batch']=record;S['pending']=None;S['status']='RUNNING';save()
 journal=A/'batches';journal.mkdir(exist_ok=True)
 with(journal/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d')+'.jsonl')).open('a')as out:out.write(json.dumps(record)+'\n')
 return max(v['height']for v in p['receipts'].values())
def idle(last_height):
 started=time.monotonic();minimum_idle_seconds=rng.uniform(30,60);S['next_batch_not_before_unix']=time.time()+minimum_idle_seconds;save()
 info=rpc('get_info');start=info['last_irreversible_block_num']+1;target=start+rng.randint(1,6)-1;cursor=start;empty=[];end=time.monotonic()+180
 while cursor<=target or not empty:
  lib=rpc('get_info')['last_irreversible_block_num']
  while cursor<=lib:
   b=rpc('get_block',{'block_num_or_id':cursor})
   if not b['transactions']:empty.append({'height':cursor,'id':b['id'],'timestamp':b['timestamp']})
   cursor+=1
  assert time.monotonic()<end,'No real empty block during bounded idle observation';time.sleep(2)
 time.sleep(max(0,minimum_idle_seconds-(time.monotonic()-started)))
 S['empty_blocks']+=len(empty);S['empty_block_samples']=(S['empty_block_samples']+empty)[-50:];save();log('EMPTY_BLOCKS.jsonl',{'UTC':now(),'after_batch':S['completed_batches'],'planned_idle_end':target,'observed':empty})
try:
 assert rpc('get_info')['chain_id']==CHAIN and rpc('get_code_hash',{'account_name':'civiccounter'})['code_hash']==Q['WASM_SHA256']
 if not S['balances']:
  with ThreadPoolExecutor(max_workers=6)as pool:values=list(pool.map(cash,ACTORS))
  S['balances']=dict(zip(ACTORS,values));S['initial_ordinary_liquid_total_smallest_units']=sum(values);assert min(values)>0
 write('PLAN.json',{'chain_id':CHAIN,'public_random_seed_SHA256':SEED,'ordinary_accounts':ACTORS,'batch_range':[1,3],'minimum_idle_seconds_range':[30,60],'idle_canonical_blocks_range':[1,6],'transfer_probability':'90% target; actual mix recorded','other_actions':['civiccounter::tick','civiccounter::note'],'max_transfer':'0.0100 AIC','min_transfer':'0.0001 AIC','scope':'Continuous low-rate business; no TPS qualification; exact signed packets are persisted before broadcast; ordinary keys only; no stake/vote/bond/pool mutations','source_SHA256':SOURCE})
 S['status']='RUNNING';save()
 while True:
  if not S['pending']:
   last=S.get('last_completed_batch',{}).get('finalized_UTC');floor=datetime.datetime.fromisoformat(last).timestamp()+30 if last else 0
   time.sleep(max(0,max(floor,S.get('next_batch_not_before_unix',0))-time.time()))
   S['pending']=make_batch();save()
  height=finish_batch(S['pending']);idle(height)
  if S['completed_batches']%20==0:
   with ThreadPoolExecutor(max_workers=6)as pool:actual=dict(zip(ACTORS,pool.map(cash,ACTORS)))
   assert actual==S['balances'],'Ordinary activity balance audit mismatch'
   if rpc('get_currency_stats',{'code':'eosio.token','symbol':'AIC'})['AIC']['supply']!='100000000.0000 AIC':raise AssertionError('Unexpected supply change')
  if not(A/'VERIFIED.json').exists()and S['business_transactions']>=50 and S['ticks']>0 and S['notes']>0 and S['empty_blocks']>=5:
   write('VERIFIED.json',{'status':'PASS','UTC':now(),'chain_id':CHAIN,'source_SHA256':SOURCE,'WASM_SHA256':Q['WASM_SHA256'],'completed_batches':S['completed_batches'],'business_transactions':S['business_transactions'],'transfers':S['transfers'],'ticks':S['ticks'],'notes':S['notes'],'observed_batch_sizes':S['batch_sizes'],'actual_empty_blocks':S['empty_blocks'],'canonical_empty_samples':S['empty_block_samples'],'sample_last_batch':S['last_completed_batch'],'ordinary_liquid_total_unchanged':True,'not_TPS':True})
except BaseException:
 error=traceback.format_exc().replace(PASSWORD,'<redacted>');S.update(status='FAIL',error=error);save();write('FAILURE_'+str(time.time_ns())+'.json',{'UTC':now(),'error':error,'pending':S.get('pending')})
 ready=E/'PREPARATION_READY.json'
 if ready.exists()and not(E/'STOP_RECEIPT.json').exists():
  value=json.loads(ready.read_text());value.update(status='ACTIVITY_FAILED',error=error);ready.write_text(json.dumps(value,indent=2)+'\n')
 print(error,flush=True);raise
