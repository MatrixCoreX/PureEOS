# Founder BP single pressure round

Founder: gptgenesisbp. Chain: 9924d9d6405276c9e4cfee86a5b497a19b5c3fa4d576508689884b8be47a0bac.

Offered80000TPS,1s warmup,12s fixed window,90s drain;8sender connections. Sent 1040000, finalized 1040000, unconfirmed 0. Fixed inclusion 34614.75TPS; fixed finality 34507.33TPS.

The producer has SHIP disabled; all other BP, nonproducing history and all six PureHistory containers were stopped during the timed window; history was restored afterward on the same host. This is not a sustained or multi-node performance qualification. Accounts, RAM, self staking, self-paid PowerUp and signatures were prepared before timing. Canonical receipts, exact integer full-ledger accounting, caps, source/binary and history ID/block positions verified. All accepted transactions remain in the chain blocklog and history index; missing0,duplicates0.

Report digest: 60aa4b710de58d8fa68bb12a4ff6931d879a54e60ddc5aa9301f403820fcf8d8. On-chain summary transaction: fb2c095e67cbfbc2f5d0fccfabf6f9d69239756fe0a16c4137035eecda7c64f9 at block 2812. Full raw evidence remains at /opt/pureeos-bp-bond-newchain-20261102-r1/pressure; no private keys are published.

Sample: https://aic.matrixai.one/#/transaction/05bec687a37abb336d316a091f3aafd4c6edd44fb743d10facbc14bc1bd253c6?block=891
