import unittest
import test_votes as reference
OWNER, CHAIN = reference.OWNER, reference.CHAIN
from producer_votes import snapshot
class BondProfileTests(unittest.TestCase):
 def read(self, abi):
  original=reference.VotesTests().rpc(iter(['a'*64,'a'*64]))
  def rpc(method,args):
   if method=='get_raw_abi':return {'code_hash':'b591ca661e8256b7d1c7370fe11e5825427c98b4f84eceb3cdf735c06e5e8170','abi_hash':abi}
   return original(method,args)
  return rpc
 def test_qualified_bond_profile(self):
  self.assertTrue(snapshot(self.read('f19e4c55e11f5029f4a161865ac0b0ea29f730d4f19fbdc6eb30c29c10ef5512'),(OWNER,),CHAIN)['available'])
 def test_same_code_wrong_abi_remains_unknown(self):
  self.assertFalse(snapshot(self.read('0'*64),(OWNER,),CHAIN)['available'])
