from pathlib import Path
import datetime,hashlib,json,random,subprocess,time,traceback
E=Path('/opt/pureeos-bp-bond-offline-five-20261102-r1');B=Path('/opt/pureeos-bp-bond-newchain-20261102-r1');V=E/'voting'
exec(compile((E/'join_controller.py').read_text().split('\ntry:\n',1)[0],str(E/'join_controller.py'),'exec'),globals())
exec(compile((E/'watch_fault.py').read_text().split('\nstopped=False',1)[0],str(E/'watch_fault.py'),'exec'),globals())
ALL=sorted({e['name']for e in BASE['nodes']}|set(NAMES));assert len(ALL)==45
R=json.loads((V/'PROGRESS.json').read_text())if(V/'PROGRESS.json').exists()else{'status':'PREPARING','transactions':{},'voters':{}}
def save():
 R['UTC']=now();p=V/'PROGRESS.pending';p.write_text(json.dumps(R,indent=2)+'\n');p.replace(V/'PROGRESS.json')
def vrow(name):
 rows=rpc('get_table_rows',{'code':'eosio','scope':'eosio','table':'votersv2','json':True,'key_type':'name','lower_bound':name,'limit':1})['rows'];assert rows and rows[0]['owner']==name;return rows[0]
try:
 assert not(E/'STOP_RECEIPT.json').exists();subprocess.run(['systemctl','start','pureeos-bond-join-wallet-20261102.service'],check=True);end=time.monotonic()+30
 while not(W/'keosd.sock').exists():assert time.monotonic()<end;time.sleep(.2)
 password=(W/'password.txt').read_text().strip();SECRETS.append(password);cli(['wallet','unlock','-n','founder-demo'],password+'\n',allow=True)
 bpkeys=json.loads((B/'private-keys.json').read_text());bpkeys.update(KEYS)
 for name in ALL:
  row=vrow(name);k=bpkeys[name]['account']['Private key'];SECRETS.append(k);cli(['wallet','import','-n','founder-demo'],k+'\n',allow=True)
  assert int(row['staked'])>0
  if row['producers']!=[name]or row['proxy']:transaction('ensure-BP-self-vote-'+name,[action('eosio','voteproducer',name,{'voter':name,'proxy':'','producers':[name]})])
  assert vrow(name)['producers']==[name]and not vrow(name)['proxy']
 if not(V/'PLAN.json').exists():
  baseline={p['owner']:int(p['total_votes'])for p in table('producersv2')};seed=hashlib.sha256((CHAIN+'|ordinary-random-voters|20261102-r1').encode()).hexdigest();rng=random.Random(int(seed,16))
  adj=['bright','silver','golden','velvet','cosmic','serene','mellow','forest','autumn','winter','spring','summer'];nouns=['willow','meadow','garden','harbor','summit','valley','stream','planet','breeze','flower','orchid','voyage','pollen','falcon','marble','petals']
  available=[a+n for a in adj for n in nouns if a+n not in ALL];assert all(len(n)==12 for n in available);voters=rng.sample(available,90)
  assigned=ALL.copy();rng.shuffle(assigned);assigned+=rng.choices(ALL,k=45);rng.shuffle(assigned)
  for generation in range(1000):
   amounts=[rng.randint(100,1000)for _ in voters];totals=baseline.copy()
   for bp,amount in zip(assigned,amounts):totals[bp]+=amount*10000
   if len(set(totals.values()))==45:break
  else:raise AssertionError('Could not generate distinct randomized vote totals')
  plan={'status':'PREPARED','UTC':now(),'chain_id':CHAIN,'random_seed_SHA256':seed,'generator':'Python random.Random / public test seed; key generation independent','random_stake_generation_attempts':generation+1,'baseline_after_all_BP_self_votes':baseline,'planned_totals_smallest_units':totals,'scope':'90 ordinary accounts: randomized permutation guarantees each BP support, plus45 uniform random choices;100..1000AIC own stake; all45 BP still self-vote','voters':[{'name':n,'BP':bp,'stake_AIC_integer':a,'stake_smallest_units':a*10000,'fund_AIC_integer':a+20}for n,bp,a in zip(voters,assigned,amounts)]}
  assert sum(v['fund_AIC_integer']for v in plan['voters'])<100000
  (V/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
 plan=json.loads((V/'PLAN.json').read_text());assert plan['chain_id']==CHAIN
 if not(V/'private-keys.json').exists():
  private={}
  for item in plan['voters']:
   out=subprocess.run([str(T/'cleos'),'create','key','--to-console'],capture_output=True,text=True,check=True,timeout=30).stdout;key={l.split(':',1)[0].strip():l.split(':',1)[1].strip()for l in out.splitlines()if ':'in l};assert 'Private key'in key and 'Public key'in key;private[item['name']]=key
  (V/'private-keys.json').write_text(json.dumps(private,indent=2)+'\n');(V/'private-keys.json').chmod(0o600)
 private=json.loads((V/'private-keys.json').read_text());SECRETS.extend(v['Private key']for v in private.values());R.update(status='ORDINARY_RANDOM_VOTING',planned=90,completed=len(R['voters']));save()
 for item in plan['voters']:
  name=item['name'];bp=item['BP'];stake=item['stake_AIC_integer'];k=private[name];cli(['wallet','import','-n','founder-demo'],k['Private key']+'\n',allow=True)
  if name in R['voters']:continue
  auth={'threshold':1,'keys':[{'key':k['Public key'],'weight':1}],'accounts':[],'waits':[]}
  transaction('create-ordinary-'+name,[action('eosio','newaccount','gptgenesisbp',{'creator':'gptgenesisbp','name':name,'owner':auth,'active':auth}),action('eosio','buyrambytes','gptgenesisbp',{'payer':'gptgenesisbp','receiver':name,'bytes':16384})])
  tx=transaction('fund-own-stake-powerup-and-random-vote-'+name,[action('eosio.token','transfer','gptgenesisbp',{'from':'gptgenesisbp','to':name,'quantity':str(item['fund_AIC_integer'])+'.0000 AIC','memo':'Ordinary voter own resources; no extra issuance'}),action('eosio','delegatebw',name,{'from':name,'receiver':name,'stake_net_quantity':'10.0000 AIC','stake_cpu_quantity':str(stake-10)+'.0000 AIC','transfer':False}),action('eosio','powerup',name,{'payer':name,'receiver':name,'days':30,'net_frac':1000000,'cpu_frac':1000000,'max_payment':'1.0000 AIC'}),action('eosio','voteproducer',name,{'voter':name,'proxy':'','producers':[bp]})])
  row=vrow(name);assert row['producers']==[bp]and not row['proxy']and int(row['staked'])==int(row['last_vote_amount'])==item['stake_smallest_units']
  delegation=rpc('get_table_rows',{'code':'eosio','scope':name,'table':'delband','json':True,'limit':10})['rows'];assert delegation and all(d['from']==d['to']==name for d in delegation)
  R['voters'][name]={'BP':bp,'stake_smallest_units':item['stake_smallest_units'],'voter':row,'canonical_transaction':tx,'delegation':delegation};R['completed']=len(R['voters']);save()
 actual={p['owner']:int(p['total_votes'])for p in table('producersv2')};assert set(actual)==set(ALL)and actual==plan['planned_totals_smallest_units']and len(set(actual.values()))==45
 selfvotes={n:vrow(n)for n in ALL};assert all(v['producers']==[n]and not v['proxy']and int(v['last_vote_amount'])>0 for n,v in selfvotes.items())
 ordinary={n:vrow(n)for n in private};assert all(n not in actual for n in ordinary)
 recipients={bp:[]for bp in ALL}
 for item in plan['voters']:recipients[item['BP']].append(item['name'])
 assert all(recipients.values());assert rpc('get_currency_stats',{'code':'eosio.token','symbol':'AIC'})['AIC']['supply']=='100000000.0000 AIC'
 out={'status':'PASS','UTC':now(),'chain_id':CHAIN,'BP_count':45,'ordinary_voter_count':90,'all_BP_self_votes':selfvotes,'all_ordinary_voters':ordinary,'recipients':recipients,'vote_totals_smallest_units':actual,'pairwise_distinct_totals':True,'random_seed_SHA256':plan['random_seed_SHA256'],'vote_precision':4,'plan':plan,'transactions':R['transactions'],'existing_320AIC_founder_supporter_preserved':True,'no_extra_issuance':True,'no_new_nodes':True}
 (V/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n');R.update(status='PASS',completed=90);save()
except BaseException:
 error=traceback.format_exc()
 for secret in SECRETS:error=error.replace(secret,'<redacted>')
 R.update(status='FAIL',error=error);save();(V/('FAILURE_'+str(time.time_ns())+'.json')).write_text(json.dumps(R,indent=2)+'\n');print(error,flush=True);raise
finally:subprocess.run(['systemctl','stop','pureeos-bond-join-wallet-20261102.service'],capture_output=True,timeout=30)
