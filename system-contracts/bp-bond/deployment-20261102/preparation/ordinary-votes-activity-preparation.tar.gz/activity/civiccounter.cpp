#include <eosio/eosio.hpp>
#include <eosio/crypto.hpp>
#include <limits>
using namespace eosio;
class [[eosio::contract("civiccounter")]] civiccounter : public contract {
public:
 using contract::contract;
 [[eosio::action]] void tick(name user, uint64_t nonce, uint64_t delta) {
  check(delta>=1 && delta<=20,"delta must be between 1 and 20");
  update(user,nonce,delta,"");
 }
 [[eosio::action]] void note(name user, uint64_t nonce, std::string memo) {
  check(!memo.empty() && memo.size()<=64,"note must contain 1..64 bytes");
  update(user,nonce,0,memo);
 }
 struct [[eosio::table]] counter {
  name owner;uint64_t nonce=0;uint64_t total=0;uint64_t notes=0;checksum256 last_note;
  uint64_t primary_key()const{return owner.value;}
 };
 using counters=multi_index<"counters"_n,counter>;
private:
 void update(name user,uint64_t nonce,uint64_t delta,const std::string& memo) {
  require_auth(user);counters rows(get_self(),get_self().value);auto existing=rows.find(user.value);
  uint64_t previous=existing==rows.end()?0:existing->nonce;
  check(previous!=std::numeric_limits<uint64_t>::max() && nonce==previous+1,"nonce must advance by one");
  auto change=[&](auto& r){
   r.owner=user;r.nonce=nonce;
   if(delta){check(r.total<=std::numeric_limits<uint64_t>::max()-delta,"counter overflow");r.total+=delta;}
   else{check(r.notes!=std::numeric_limits<uint64_t>::max(),"note count overflow");++r.notes;r.last_note=sha256(memo.data(),memo.size());}
  };
  if(existing==rows.end())rows.emplace(user,change);else rows.modify(existing,same_payer,change);
 }
};
EOSIO_DISPATCH(civiccounter,(tick)(note))
