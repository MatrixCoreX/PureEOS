from pathlib import Path
import datetime,hashlib,json,subprocess,time,traceback
E=Path('/opt/pureeos-bp-bond-offline-five-20261102-r1');A=E/'activity';A.mkdir(exist_ok=True);A.chmod(0o700)
source=r'''#include <eosio/eosio.hpp>
#include <eosio/crypto.hpp>
#include <limits>
using namespace eosio;
class [[eosio::contract("civiccounter")]] civiccounter : public contract {
public:
 using contract::contract;
 [[eosio::action]] void tick(name user, uint64_t nonce, uint64_t delta) {
  check(delta>=1 && delta<=20,"delta must be between 1 and 20");
  update(user,nonce,delta,"");
 }
 [[eosio::action]] void note(name user, uint64_t nonce, std::string memo) {
  check(!memo.empty() && memo.size()<=64,"note must contain 1..64 bytes");
  update(user,nonce,0,memo);
 }
 struct [[eosio::table]] counter {
  name owner;uint64_t nonce=0;uint64_t total=0;uint64_t notes=0;checksum256 last_note;
  uint64_t primary_key()const{return owner.value;}
 };
 using counters=multi_index<"counters"_n,counter>;
private:
 void update(name user,uint64_t nonce,uint64_t delta,const std::string& memo) {
  require_auth(user);counters rows(get_self(),get_self().value);auto existing=rows.find(user.value);
  uint64_t previous=existing==rows.end()?0:existing->nonce;
  check(previous!=std::numeric_limits<uint64_t>::max() && nonce==previous+1,"nonce must advance by one");
  auto change=[&](auto& r){
   r.owner=user;r.nonce=nonce;
   if(delta){check(r.total<=std::numeric_limits<uint64_t>::max()-delta,"counter overflow");r.total+=delta;}
   else{check(r.notes!=std::numeric_limits<uint64_t>::max(),"note count overflow");++r.notes;r.last_note=sha256(memo.data(),memo.size());}
  };
  if(existing==rows.end())rows.emplace(user,change);else rows.modify(existing,same_payer,change);
 }
};
EOSIO_DISPATCH(civiccounter,(tick)(note))
'''
(A/'civiccounter.cpp').write_text(source);C=A/'contracts';C.mkdir(exist_ok=True);SDK=Path('/opt/pureeos-v1-release-20261101-r1/sdk-package/pureeos-cdt-1.0.0/bin/cdt-cpp')
build=subprocess.run([str(SDK),'-abigen','-contract','civiccounter','-o',str(C/'civiccounter.wasm'),str(A/'civiccounter.cpp')],capture_output=True,text=True,timeout=180);(A/'BUILD.log').write_text(build.stdout+build.stderr);assert build.returncode==0,build.stdout+build.stderr
assert(C/'civiccounter.abi').exists()
exec(compile((E/'join_controller.py').read_text().split('\ntry:\n',1)[0].replace("'founder-demo'","'activity-demo'"),str(E/'join_controller.py'),'exec'),globals())
exec(compile((E/'watch_fault.py').read_text().split('\nstopped=False',1)[0],str(E/'watch_fault.py'),'exec'),globals())
W=A/'wallet';W.mkdir(exist_ok=True);W.chmod(0o700);BASE=[str(T/'cleos'),'--no-auto-keosd','--url','http://127.0.0.1:8888','--wallet-url','unix://'+str(W/'keosd.sock')]
R=json.loads((A/'PREPARATION.json').read_text())if(A/'PREPARATION.json').exists()else{'status':'WAITING_VOTERS','transactions':{},'checks':[]}
def save():
 R['UTC']=now();p=A/'PREPARATION.pending';p.write_text(json.dumps(R,indent=2)+'\n');p.replace(A/'PREPARATION.json')
def check(label,condition,**details):assert condition,label;R['checks'].append({'check':label,'status':'PASS',**details});save()
def one(name):
 page=rpc('get_table_rows',{'code':'civiccounter','scope':'civiccounter','table':'counters','json':True,'key_type':'name','lower_bound':name,'limit':1})['rows'];return page[0]if page and page[0]['owner']==name else None
def reject(label,actions,expected):
 before=one(actors[0]);cash=rpc('get_currency_balance',{'code':'eosio.token','account':actors[0],'symbol':'AIC'});info=rpc('get_info');bid=bytes.fromhex(info['last_irreversible_block_id']);trx={'expiration':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=180)).strftime('%Y-%m-%dT%H:%M:%S'),'ref_block_num':info['last_irreversible_block_num']&65535,'ref_block_prefix':int.from_bytes(bid[8:12],'little'),'max_net_usage_words':0,'max_cpu_usage_ms':0,'delay_sec':0,'context_free_actions':[],'actions':actions,'transaction_extensions':[]};result=cli(['push','transaction',json.dumps(trx),'-j'],allow=True);message=result.stdout+result.stderr
 for secret in SECRETS:message=message.replace(secret,'<redacted>')
 check(label,result.returncode!=0 and expected in message,error=message[-1200:]);check(label+' atomic state and balance rollback',one(actors[0])==before and rpc('get_currency_balance',{'code':'eosio.token','account':actors[0],'symbol':'AIC'})==cash)
try:
 save();end=time.monotonic()+10800
 while not(E/'voting/RESULT.json').exists():assert time.monotonic()<end;time.sleep(3)
 votes=json.loads((E/'voting/RESULT.json').read_text());assert votes['status']=='PASS';private=json.loads((E/'voting/private-keys.json').read_text());actors=list(private);SECRETS.extend(v['Private key']for v in private.values())
 if not(A/'private-contract-key.json').exists():
  result=subprocess.run([str(T/'cleos'),'create','key','--to-console'],capture_output=True,text=True,check=True);k={l.split(':',1)[0].strip():l.split(':',1)[1].strip()for l in result.stdout.splitlines()if ':'in l};(A/'private-contract-key.json').write_text(json.dumps(k)+'\n');(A/'private-contract-key.json').chmod(0o600)
 k=json.loads((A/'private-contract-key.json').read_text());SECRETS.append(k['Private key'])
 unit='[Unit]\nDescription=Private ordinary-activity signing wallet\nAfter=network-online.target\n[Service]\nType=simple\nExecStart='+str(T/'keosd')+' --http-server-address "" --unix-socket-path='+str(W/'keosd.sock')+' --wallet-dir='+str(W)+' --unlock-timeout=90000\nRestart=on-failure\nRestartSec=3\nNoNewPrivileges=true\nUMask=0077\n[Install]\nWantedBy=multi-user.target\n';Path('/etc/systemd/system/pureeos-ordinary-activity-wallet-20261102.service').write_text(unit);subprocess.run(['systemctl','daemon-reload'],check=True);subprocess.run(['systemctl','enable','--now','pureeos-ordinary-activity-wallet-20261102.service'],check=True,capture_output=True)
 end=time.monotonic()+30
 while not(W/'keosd.sock').exists():assert time.monotonic()<end;time.sleep(.2)
 if not(W/'password.txt').exists():cli(['wallet','create','-n','activity-demo','--file',str(W/'password.txt')]);(W/'password.txt').chmod(0o600)
 password=(W/'password.txt').read_text().strip();SECRETS.append(password);cli(['wallet','unlock','-n','activity-demo'],password+'\n',allow=True)
 for key in [k,*private.values()]:cli(['wallet','import','-n','activity-demo'],key['Private key']+'\n',allow=True)
 creator_key=json.loads((B/'private-keys.json').read_text())['gptgenesisbp']['account']['Private key'];SECRETS.append(creator_key);cli(['wallet','import','-n','activity-demo'],creator_key+'\n',allow=True)
 auth={'threshold':1,'keys':[{'key':k['Public key'],'weight':1}],'accounts':[],'waits':[]}
 transaction('create-civiccounter',[action('eosio','newaccount','gptgenesisbp',{'creator':'gptgenesisbp','name':'civiccounter','owner':auth,'active':auth}),action('eosio','buyrambytes','gptgenesisbp',{'payer':'gptgenesisbp','receiver':'civiccounter','bytes':1048576})])
 transaction('fund-own-civiccounter-resources',[action('eosio.token','transfer','gptgenesisbp',{'from':'gptgenesisbp','to':'civiccounter','quantity':'500.0000 AIC','memo':'Ordinary application deployment resources'}),action('eosio','delegatebw','civiccounter',{'from':'civiccounter','receiver':'civiccounter','stake_net_quantity':'10.0000 AIC','stake_cpu_quantity':'100.0000 AIC','transfer':False}),action('eosio','powerup','civiccounter',{'payer':'civiccounter','receiver':'civiccounter','days':30,'net_frac':1000000000,'cpu_frac':1000000000,'max_payment':'1.0000 AIC'})])
 if 'deploy-civiccounter'not in R['transactions']:
  before=rpc('get_info');out=json.loads(cli(['set','contract','civiccounter',str(C),'civiccounter.wasm','civiccounter.abi','-p','civiccounter@active','-j']).stdout);tid=out['transaction_id'];height=int(out['processed']['block_num']);end=time.monotonic()+180
  while rpc('get_info')['last_irreversible_block_num']<height:assert time.monotonic()<end;time.sleep(.2)
  block=rpc('get_block',{'block_num_or_id':height});assert any((t['trx']if isinstance(t['trx'],str)else t['trx']['id'])==tid for t in block['transactions']);R['transactions']['deploy-civiccounter']={'id':tid,'height':height,'block_id':block['id']};save()
 wasm=hashlib.sha256((C/'civiccounter.wasm').read_bytes()).hexdigest();check('deployed civiccounter matches built WASM',rpc('get_code_hash',{'account_name':'civiccounter'})['code_hash']==wasm)
 transaction('qualification-positive-tick',[action('civiccounter','tick',actors[0],{'user':actors[0],'nonce':1,'delta':7})]);check('real tick updates own fixed-size row',one(actors[0])['nonce']==1 and one(actors[0])['total']==7)
 reject('wrong user authority rejected',[action('civiccounter','tick',actors[1],{'user':actors[0],'nonce':2,'delta':1})],'missing authority')
 reject('replayed business nonce rejected',[action('civiccounter','tick',actors[0],{'user':actors[0],'nonce':1,'delta':1})],'nonce must advance by one')
 reject('out-of-range increment rejected',[action('civiccounter','tick',actors[0],{'user':actors[0],'nonce':2,'delta':21})],'delta must be between 1 and 20')
 reject('overlong note rejected',[action('civiccounter','note',actors[0],{'user':actors[0],'nonce':2,'memo':'x'*65})],'note must contain 1..64 bytes')
 reject('failed contract rolls back prior cross-contract transfer',[action('eosio.token','transfer',actors[0],{'from':actors[0],'to':actors[1],'quantity':'0.0001 AIC','memo':'Expected atomic rollback'}),action('civiccounter','tick',actors[0],{'user':actors[0],'nonce':1,'delta':1})],'nonce must advance by one')
 transaction('qualification-positive-note',[action('civiccounter','note',actors[0],{'user':actors[0],'nonce':2,'memo':'Compute allocation'})]);check('real note changes nonce/hash without altering counter',one(actors[0])['nonce']==2 and one(actors[0])['notes']==1 and one(actors[0])['total']==7)
 # Qualify the exact pre-sign/packed submission interface without broadcasting.
 info=rpc('get_info');bid=bytes.fromhex(info['last_irreversible_block_id']);trx={'expiration':(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=180)).strftime('%Y-%m-%dT%H:%M:%S'),'ref_block_num':info['last_irreversible_block_num']&65535,'ref_block_prefix':int.from_bytes(bid[8:12],'little'),'max_net_usage_words':0,'max_cpu_usage_ms':0,'delay_sec':0,'context_free_actions':[],'actions':[action('eosio.token','transfer',actors[0],{'from':actors[0],'to':actors[1],'quantity':'0.0001 AIC','memo':'Pre-sign interface only'})],'transaction_extensions':[]}
 packed=json.loads(cli(['push','transaction',json.dumps(trx),'-d','--return-packed','-j']).stdout);check('packed pre-sign interface is valid and does not broadcast',bool(packed.get('packed_trx'))and bool(packed.get('signatures'))and packed.get('compression')in ['none',0]);(A/'SIGNING_SAMPLE.json').write_text(json.dumps({'status':'PASS','not_broadcast':True,'transaction_id':hashlib.sha256(bytes.fromhex(packed['packed_trx'])).hexdigest(),'packed':packed},indent=2)+'\n')
 check('all45 distinct votes unchanged by ordinary app preparation',{p['owner']:int(p['total_votes'])for p in table('producersv2')}==votes['vote_totals_smallest_units']);check('supply unchanged',rpc('get_currency_stats',{'code':'eosio.token','symbol':'AIC'})['AIC']['supply']=='100000000.0000 AIC')
 out={'status':'PASS','UTC':now(),'chain_id':CHAIN,'account':'civiccounter','CDT':str(SDK),'source_SHA256':hashlib.sha256((A/'civiccounter.cpp').read_bytes()).hexdigest(),'WASM_SHA256':wasm,'ABI_JSON_SHA256':hashlib.sha256((C/'civiccounter.abi').read_bytes()).hexdigest(),'checks':R['checks'],'transactions':R['transactions'],'key_and_wallet_private':True,'runtime_whitelist_changed':False,'no_TPS_claim':True};(A/'QUALIFIED.json').write_text(json.dumps(out,indent=2)+'\n');R.update(status='PASS');save()
except BaseException:
 error=traceback.format_exc()
 for secret in SECRETS:error=error.replace(secret,'<redacted>')
 R.update(status='FAIL',error=error);save();(A/('FAILURE_'+str(time.time_ns())+'.json')).write_text(json.dumps(R,indent=2)+'\n');print(error,flush=True);raise
