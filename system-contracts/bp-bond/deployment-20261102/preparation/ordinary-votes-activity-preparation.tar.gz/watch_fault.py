from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,json,subprocess,time,traceback,urllib.request,urllib.error
B=Path('/opt/pureeos-bp-bond-newchain-20261102-r1');E=Path('/opt/pureeos-bp-bond-offline-five-20261102-r1');PLAN=json.loads((E/'PLAN.json').read_text());BASE_PLAN=json.loads((B/'PLAN.json').read_text());NAMES=[v['name']for v in PLAN['nodes'][1:]];CHAIN=PLAN['chain_id'];STATE={'status':'WAITING_FIVE_REGISTRATIONS','started_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};POLICIES=json.loads((E/'POLICY_HISTORY.json').read_text())if(E/'POLICY_HISTORY.json').exists()else{}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path,data):
 p=E/(path+'.pending');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(E/path)
def status(s,**kw):STATE.update(status=s,UTC=now(),**kw);write('STATUS.json',STATE)
def rpc(m,d={},port=8888):
 assert m.startswith('get_'),'Read retry helper must never submit a transaction'
 for attempt in range(4):
  try:return json.load(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+str(port)+'/v1/chain/'+m,json.dumps(d).encode(),{'Content-Type':'application/json'}),timeout=10))
  except (urllib.error.URLError,TimeoutError,ConnectionError)as error:
   body=error.read().decode(errors='replace')if isinstance(error,urllib.error.HTTPError)else str(error)
   entry={'UTC':now(),'method':m,'port':port,'request':d,'attempt':attempt+1,'error':str(error),'response_body':body,'read_only':True}
   with(E/'RPC_READ_RETRIES.jsonl').open('a')as out:out.write(json.dumps(entry)+'\n')
   if isinstance(error,urllib.error.HTTPError)and error.code not in [500,502,503,504]:raise
   if attempt==3:raise
   time.sleep(.5*(attempt+1))
def table(t):
 rows=[];lower='';end=time.monotonic()+90
 while True:
  v=rpc('get_table_rows',{'code':'eosio','scope':'eosio','table':t,'json':True,'lower_bound':lower,'limit':1000});following=str(v.get('next_key',''))
  if v.get('more')and following==lower:assert not v['rows']and time.monotonic()<end;time.sleep(.2);continue
  rows.extend(v['rows'])
  if not v.get('more'):return rows
  assert following and time.monotonic()<end;lower=following

def policies():
 s=rpc('get_producer_schedule');f=rpc('get_finalizer_info');p=s['active'];a=f['active_finalizer_policy'];names=[v['producer_name']for v in p['producers']];fn=[v['description']for v in a['finalizers']]
 key=str(p['version'])
 if key not in POLICIES:
  POLICIES[key]={'observed_UTC':now(),'producer_policy':p,'finalizer_policy':a,'coherent_members':set(names)==set(fn)};write('POLICY_HISTORY.json',POLICIES)
 return s,f,names,fn

def snapshot():
 i=rpc('get_info');s,f,p,fn=policies();c=table('rotcands');b=table('bpbonds');r=table('rotation')[0]
 assert i['chain_id']==CHAIN
 return {'UTC':now(),'info':i,'schedule':s,'finalizers':f,'producer_names':p,'finalizer_names':fn,'rotation':r,'new_candidates':[v for v in c if v['owner']in NAMES],'healthy_banned':[v for v in c if v['owner']not in NAMES and v['banned']],'bond_configuration':table('bpbondcfg')[0],'new_bonds':[v for v in b if v['owner']in NAMES],'all_bond_count':len(b)}

def healthy_node(entry):
 name=entry['name'];idx=entry['index'];port=8888 if idx==0 else 12000+idx
 unit='pureeos-bp-bond-founder-20261102.service'if idx==0 else 'pureeos-bond-bp-'+name+'-20261102.service'
 assert subprocess.run(['systemctl','is-active','--quiet',unit]).returncode==0,unit+' not active'
 v=rpc('get_info',port=port);main=rpc('get_info');assert v['chain_id']==CHAIN and main['head_block_num']-v['head_block_num']<=8
 assert rpc('get_block',{'block_num_or_id':v['last_irreversible_block_num']})['id']==v['last_irreversible_block_id']
 return {'name':name,'head':v['head_block_num'],'LIB':v['last_irreversible_block_num'],'unit':unit}

def healthy_all():
 with ThreadPoolExecutor(max_workers=6)as pool:nodes=list(pool.map(healthy_node,BASE_PLAN['nodes']))
 h=rpc('get_info',port=8890);main=rpc('get_info');assert h['chain_id']==CHAIN and main['head_block_num']-h['head_block_num']<=10
 assert rpc('get_block',{'block_num_or_id':h['last_irreversible_block_num']})['id']==h['last_irreversible_block_id']
 return {'UTC':now(),'nodes':nodes,'history':h}

stopped=False
try:
 status('WAITING_FIVE_REGISTRATIONS');end=time.monotonic()+1800
 while True:
  join=json.loads((E/'JOIN_PROGRESS.json').read_text())if(E/'JOIN_PROGRESS.json').exists()else{}
  assert join.get('status')!='FAIL',join.get('error','Join failed')
  done=[n for n in NAMES if n in join.get('joined',{})]
  status('WAITING_FIVE_REGISTRATIONS',joined=done)
  if len(done)==5:break
  assert time.monotonic()<end,'Five registration deadline exceeded';time.sleep(5)
 write('ALL5_JOINED.json',join);status('WAITING_REAL_NATIVE_DUTY_AND_PRODUCTION');end=time.monotonic()+21600;last_record=0
 while True:
  snap=snapshot();rows={v['owner']:v for v in table('producersv2')};on=[n for n in NAMES if n in snap['producer_names']and n in snap['finalizer_names']];produced={n:int(rows[n]['unpaid_blocks'])for n in NAMES}
  assert not snap['healthy_banned']and not any(v['banned']for v in snap['new_candidates'])
  status('WAITING_REAL_NATIVE_DUTY_AND_PRODUCTION',native_duty=on,unpaid_blocks=produced,head=snap['info']['head_block_num'],LIB=snap['info']['last_irreversible_block_num'],rotation_incoming=snap['rotation']['incoming'],rotation_completed=snap['rotation']['completed'])
  if time.monotonic()-last_record>30:
   with(E/'ADMISSION_OBSERVATIONS.jsonl').open('a')as out:out.write(json.dumps(snap)+'\n')
   last_record=time.monotonic()
  # Choose a normal entrant observation, so an offline entrant is judged by
  # the real three-window rule; no policy timing or votes are changed.
  if (E/'PREPARATION_READY.json').exists()and json.loads((E/'PREPARATION_READY.json').read_text())['status']=='PASS'and (E/'voting/RESULT.json').exists()and json.loads((E/'voting/RESULT.json').read_text())['status']=='PASS'and len(on)==5 and all(v>0 for v in produced.values())and snap['rotation']['stage']==2 and snap['rotation']['incoming']in NAMES:
   assert len(snap['producer_names'])==len(snap['finalizer_names'])==21 and snap['finalizers']['active_finalizer_policy']['threshold']==15
   health=healthy_all();again=snapshot()
   if not all(n in again['producer_names']and n in again['finalizer_names']for n in NAMES):continue
   assert not again['healthy_banned']and not any(v['banned']for v in again['new_candidates'])
   votes={v['description']:v for v in again['finalizers'].get('last_tracked_votes',[])}
   assert all(n in votes and votes[n]['voted_for_block_num']>=again['info']['last_irreversible_block_num']-12 for n in again['finalizer_names'])
   assert int(again['bond_configuration']['locked'])==4500000000 and again['all_bond_count']==45
   write('PRE_STOP_HEALTH.json',health);again['new_producers']=[rows[n]for n in NAMES];again['unpaid_blocks']=produced;write('PRE_STOP.json',again);break
  assert time.monotonic()<end,'No genuine joint native duty/production within six hours';time.sleep(2)
 units=['pureeos-bond-bp-'+n+'-20261102.service'for n in NAMES]
 assert all('-'+n+'-'in u for n,u in zip(NAMES,units))
 started=now();subprocess.run(['systemctl','stop',*units],check=True,timeout=150);stopped=True
 subprocess.run(['systemctl','disable',*units],check=True,capture_output=True)
 assert all(subprocess.run(['systemctl','is-active','--quiet',u]).returncode!=0 for u in units)
 stop={'started_UTC':started,'finished_UTC':now(),'only_units':units,'after':rpc('get_info'),'registration_revoked':False,'maintenance_requested':False,'remaining_healthy_finalizers':16,'quorum':15}
 write('STOP_RECEIPT.json',stop);status('FIVE_STOPPED_OBSERVING_REAL_BLACKLIST',stop=stop)
 end=time.monotonic()+21600;last_lib=rpc('get_info')['last_irreversible_block_num'];last_advanced=time.monotonic();last_key=None;last_health=0;before=rpc('get_info')
 while True:
  snap=snapshot();lib=snap['info']['last_irreversible_block_num']
  if lib>last_lib:last_lib=lib;last_advanced=time.monotonic()
  if time.monotonic()-last_advanced>90:
   restore=[u for u,n in zip(units,NAMES)if not next(v for v in snap['new_candidates']if v['owner']==n)['banned']]
   if restore:subprocess.run(['systemctl','start',*restore],check=True,timeout=150)
   write('SAFETY_RECOVERY.json',{'UTC':now(),'reason':'No LIB advance for90seconds; fault campaign interrupted','restarted_only_not_banned_units':restore,'snapshot':snap});raise RuntimeError('Finality stall safety recovery; do not claim fault PASS')
  assert not snap['healthy_banned'],'Healthy BP falsely banned'
  key=(tuple((v['owner'],v['zero_windows'],bool(v['banned']))for v in snap['new_candidates']),snap['schedule']['active']['version'],int(snap['bond_configuration']['slash_pending']))
  with(E/'FAULT_OBSERVATIONS.jsonl').open('a')as out:out.write(json.dumps(snap)+'\n')
  if key!=last_key:
   write('EVENT_'+str(snap['info']['head_block_num'])+'.json',snap);last_key=key
  if time.monotonic()-last_health>60:write('LATEST_HEALTH.json',healthy_all());last_health=time.monotonic()
  banned=[v['owner']for v in snap['new_candidates']if v['banned']]
  status('FIVE_STOPPED_OBSERVING_REAL_BLACKLIST',banned=banned,zero_windows={v['owner']:v['zero_windows']for v in snap['new_candidates']},head=snap['info']['head_block_num'],LIB=lib,active_new=[n for n in NAMES if n in snap['producer_names']or n in snap['finalizer_names']])
  if len(banned)==5 and all(int(v['ban_record_block'])<=lib for v in snap['new_bonds']):
   assert all(v['state']==4 and int(v['balance'])==0 and int(v['forfeited'])==100000000 and int(v['settled'])==0 for v in snap['new_bonds'])
   assert int(snap['bond_configuration']['locked'])==4000000000 and int(snap['bond_configuration']['slash_pending'])==500000000 and int(snap['bond_configuration']['slash_settled'])==0
   snap['before_fault']=before;write('ALL5_BLACKLISTED_IRREVERSIBLE.json',snap);status('ALL5_BLACKLISTED_AWAITING_POSTCHECKS',banned=banned);break
  assert time.monotonic()<end,'Five permanent bans not all observed within six hours; actual state retained';time.sleep(5)
except BaseException:
 status('FAIL',error=traceback.format_exc(),stopped=stopped);raise
