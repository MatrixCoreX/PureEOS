from pathlib import Path
import datetime,hashlib,json,subprocess,time,traceback,urllib.request
E=Path('/opt/pureeos-bp-bond-offline-five-20261102-r1')
exec(compile((E/'join_controller.py').read_text().split('\ntry:\n',1)[0],str(E/'join_controller.py'),'exec'),globals())
exec(compile((E/'watch_fault.py').read_text().split('\nstopped=False',1)[0],str(E/'watch_fault.py'),'exec'),globals())
POLICIES=json.loads((E/'POLICY_HISTORY.json').read_text());STATE=json.loads((E/'STATUS.json').read_text());CHECKS=[]
activity_before=json.loads((E/'activity/STATE.json').read_text())['business_transactions']
def check(label,condition,**evidence):
 assert condition,label
 CHECKS.append({'check':label,'status':'PASS',**evidence});write('POSTCHECK_PROGRESS.json',{'status':'RUNNING','UTC':now(),'checks':CHECKS})
def balance(name):
 v=rpc('get_currency_balance',{'code':'eosio.token','account':name,'symbol':'AIC'})
 return 0 if not v else int(v[0].split()[0].replace('.',''))
def one(t,n):
 v=rpc('get_table_rows',{'code':'eosio','scope':'eosio','table':t,'json':True,'key_type':'name','lower_bound':n,'limit':1})['rows'];assert v and v[0]['owner']==n;return v[0]
def forbidden(label,code,name,actor,data,expected):
 before={'escrow':balance('eosio.bond'),'pool':balance('eosio.bslash'),'cfg':table('bpbondcfg')[0]}
 result=cli(['push','action',code,name,json.dumps(data),'-p',actor+'@active','-j'],allow=True)
 message=result.stdout+result.stderr
 for secret in SECRETS:message=message.replace(secret,'<redacted>')
 check(label,result.returncode!=0 and expected in message,expected_rejection=expected,observed_error=message[-2500:])
 after={'escrow':balance('eosio.bond'),'pool':balance('eosio.bslash'),'cfg':table('bpbondcfg')[0]};check(label+' atomic custody/accounting rollback',before==after)
def slot(text):
 stamp=datetime.datetime.fromisoformat(text.replace('Z','+00:00'))
 if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=datetime.timezone.utc)
 return int((stamp.timestamp()-946684800)*2)
BLOCKS={}
def block(n):
 if n not in BLOCKS:BLOCKS[n]=rpc('get_block',{'block_num_or_id':n})
 return BLOCKS[n]

def proof():
 banned=json.loads((E/'ALL5_BLACKLISTED_IRREVERSIBLE.json').read_text());stop=json.loads((E/'STOP_RECEIPT.json').read_text());pre=json.loads((E/'PRE_STOP.json').read_text());lo0=pre['info']['head_block_num'];hi0=banned['info']['last_irreversible_block_num'];out=[]
 for c in banned['new_candidates']:
  n=c['owner'];b=next(v for v in banned['new_bonds']if v['owner']==n)
  check(n+' genuine three-window permanent ban',c['banned']and c['zero_windows']==3 and len(set(c['evidence_slots']))==3 and list(c['evidence_slots'])==sorted(c['evidence_slots'])and int(b['ban_final_block'])<=int(b['ban_record_block'])<=hi0)
  windows=[]
  for start,version in zip(c['evidence_slots'],c['evidence_policies']):
   p=POLICIES[str(version)];members=[v['producer_name']for v in p['producer_policy']['producers']]
   check(n+' assigned native zero window '+str(start),len(members)==21 and members[(start//12)%21]==n and p['coherent_members']and p['finalizer_policy']['threshold']==15)
   low=lo0;high=hi0
   while low<high:
    mid=(low+high)//2
    if slot(block(mid)['timestamp'])<start:low=mid+1
    else:high=mid
   after=block(low);before=block(low-1)
   check(n+' canonical empty production window '+str(start),slot(before['timestamp'])<start and slot(after['timestamp'])>=start+12 and start+12>slot(stop['started_UTC']))
   windows.append({'start_slot':start,'end_exclusive_slot':start+12,'native_policy_version':version,'owner':n,'before':{'height':low-1,'id':before['id'],'timestamp':before['timestamp']},'after':{'height':low,'id':after['id'],'timestamp':after['timestamp']}})
  decision=block(int(b['ban_record_block']));out.append({'owner':n,'candidate':c,'bond':b,'windows':windows,'irreversible_decision':{'height':int(b['ban_record_block']),'id':decision['id'],'timestamp':decision['timestamp']}})
 write('CANONICAL_BLACKLIST_EVIDENCE.json',{'status':'PASS','UTC':now(),'chain_id':CHAIN,'last_irreversible_block':hi0,'records':out})
 return out
try:
 status('POST_BLACKLIST_FINANCIAL_AND_FUNCTIONAL_CHECKS')
 assert(E/'ALL5_BLACKLISTED_IRREVERSIBLE.json').exists()
 evidence=proof();cfg=table('bpbondcfg')[0];check('exact 40 healthy locked bonds after five genuine forfeitures',int(cfg['locked'])==4000000000 and int(cfg['slash_pending'])+int(cfg['slash_settled'])==500000000)
 if not(E/'PRE_SETTLEMENT.json').exists():write('PRE_SETTLEMENT.json',{'UTC':now(),'configuration':cfg,'escrow_smallest_units':balance('eosio.bond'),'pool_smallest_units':balance('eosio.bslash'),'snapshot':snapshot()})
 initial=json.loads((E/'PRE_SETTLEMENT.json').read_text());check('forfeitures first locked as pending liability',int(initial['configuration']['slash_pending'])==500000000 and int(initial['configuration']['slash_settled'])==0 and initial['escrow_smallest_units']==4500000000 and initial['pool_smallest_units']==0)
 subprocess.run(['systemctl','start','pureeos-bond-join-wallet-20261102.service'],check=True)
 end=time.monotonic()+30
 while not(W/'keosd.sock').exists():assert time.monotonic()<end;time.sleep(.2)
 password=(W/'password.txt').read_text().strip();SECRETS.append(password);cli(['wallet','unlock','-n','founder-demo'],password+'\n',allow=True)
 actor='testusaaaaaa';cli(['wallet','import','-n','founder-demo'],PRIVATE[actor]['Private key']+'\n',allow=True)
 check('permissionless settlement signer is ordinary non-BP',actor not in {v['owner']for v in table('producersv2')})
 before_producers={v['owner']:v for v in table('producersv2')};write('BANNED_PRODUCERS_BEFORE_POSTCHECKS.json',{n:before_producers[n]for n in NAMES})
 for n in NAMES:
  check(n+' sufficient liquid for blacklist rebond control',balance(n)>=100000000,liquid_smallest_units=balance(n))
  forbidden(n+' refund denied','eosio','refundbond',n,{'producer':n},'BP bond has not completed duty handoff')
  forbidden(n+' maintenance cannot hide permanent ban','eosio','setmaint',n,{'producer':n,'maintenance':True},'permanently banned producer cannot use maintenance')
  forbidden(n+' maintenance resume cannot clear permanent ban','eosio','setmaint',n,{'producer':n,'maintenance':False},'permanently banned producer cannot use maintenance')
  forbidden(n+' exit denied','eosio','exitbond',n,{'producer':n},'BP bond is not active')
  forbidden(n+' permanent ban denies rebond despite sufficient funds','eosio','bondbp',n,{'producer':n},'permanently banned producer cannot post a BP bond')
  forbidden(n+' regproducer cannot regain admission','eosio','regproducer',n,{'producer':n,'producer_key':KEYS[n]['production']['Public key'],'url':'https://aic.matrixai.one','location':0},'producer must lock 10000.0000 AIC BP bond before registration')
  forbidden(n+' regproducer2 cannot regain admission','eosio','regproducer2',n,{'producer':n,'producer_authority':[0,{'threshold':1,'keys':[{'key':KEYS[n]['production']['Public key'],'weight':1}]}],'url':'https://aic.matrixai.one','location':0},'producer must lock 10000.0000 AIC BP bond before registration')
  forbidden(n+' wrong actor cannot refund','eosio','refundbond',actor,{'producer':n},'missing authority')
  # Honest already-produced rewards remain recorded. This live run is less
  # than24h, so the production claim interval must still reject early claims.
  last=datetime.datetime.fromisoformat(before_producers[n]['last_claim_time']).replace(tzinfo=datetime.timezone.utc)
  check(n+' live reward interval remains under24h',(datetime.datetime.now(datetime.timezone.utc)-last).total_seconds()<86400)
  forbidden(n+' historical reward eligibility preserved and cooldown enforced','eosio','claimrewards',n,{'owner':n},'already claimed rewards within past day')
  tx=transaction('postban-self-vote-'+n,[action('eosio','voteproducer',n,{'voter':n,'proxy':'','producers':[n]})])
  c=one('rotcands',n);b=one('bpbonds',n);check(n+' own vote cannot clear ban or queue exclusion',c['banned']and c['zero_windows']==3 and int(c['ticket'])==0 and b['state']==4,transaction=tx)
  tx=transaction('postban-ordinary-asset-transfer-'+n,[action('eosio.token','transfer',n,{'from':n,'to':'gptgenesisbp','quantity':'0.0001 AIC','memo':'Post-ban ordinary balance remains spendable'})]);check(n+' ordinary assets remain usable',bool(tx['id']),transaction=tx)
 for pool in ['eosio.bond','eosio.bslash']:
  forbidden(pool+' unauthorized transfer denied','eosio.token','transfer',actor,{'from':pool,'to':actor,'quantity':'0.0001 AIC','memo':'Expected unauthorized attempt'},'missing authority')
 for n in NAMES:
  row=one('bpbonds',n);check(n+' settlement decision already irreversible',rpc('get_info')['last_irreversible_block_num']>=int(row['ban_record_block']))
  tx=transaction('postban-permissionless-settlement-'+n,[action('eosio','settlebond',actor,{'producer':n})]);row=one('bpbonds',n)
  check(n+' exact one-time settlement to locked pool',int(row['forfeited'])==int(row['settled'])==100000000 and row['state']==4 and int(row['balance'])==0,transaction=tx,signer=actor)
  forbidden(n+' repeated settlement denied','eosio','settlebond',actor,{'producer':n},'no unsettled BP forfeiture')
 forbidden('funded forfeiture pool rejects unauthorized withdrawal','eosio.token','transfer',actor,{'from':'eosio.bslash','to':actor,'quantity':'1.0000 AIC','memo':'Expected unauthorized withdrawal from funded pool'},'missing authority')
 cfg=table('bpbondcfg')[0];check('final pool and escrow exact reconciled balances',int(cfg['locked'])==4000000000 and int(cfg['slash_pending'])==0 and int(cfg['slash_settled'])==500000000 and int(cfg['refunded'])==0 and balance('eosio.bond')==4000000000 and balance('eosio.bslash')==500000000)
 bonds=table('bpbonds');cands=table('rotcands');healthy={v['name']for v in BASE_PLAN['nodes']}
 check('all40 healthy bonds untouched and no false bans',len(bonds)==45 and all(v['state']==0 and int(v['balance'])==100000000 and int(v['forfeited'])==0 for v in bonds if v['owner']in healthy)and not any(v['banned']for v in cands if v['owner']in healthy))
 end=time.monotonic()+5400;before=rpc('get_info')
 while True:
  snap=snapshot();new_in_active=set(NAMES)&(set(snap['producer_names'])|set(snap['finalizer_names']))
  status('WAITING_NATIVE_REPLACEMENT_AND_HISTORY',new_banned_members_still_in_native_policies=sorted(new_in_active),head=snap['info']['head_block_num'],LIB=snap['info']['last_irreversible_block_num'])
  if not new_in_active and len(snap['producer_names'])==len(snap['finalizer_names'])==21 and snap['finalizers']['active_finalizer_policy']['threshold']==15 and int(snap['rotation']['ranked_count'])==40:break
  assert time.monotonic()<end,'Native backfill deadline; do not claim PASS';time.sleep(5)
 check('real native21/15 policies backfilled exclusively by healthy members',set(snap['producer_names'])==set(snap['finalizer_names'])and set(snap['producer_names'])<=healthy)
 # With all five evicted from both actual policies, rotate their registry keys
 # through ordinary own-authorized actions and prove the ban is still sticky.
 keyfile=E/'postcheck-private-keys.json'
 if not keyfile.exists():
  fresh={}
  for n in NAMES:
   fresh[n]={}
   for role in ['peer','bls']:
    cmd=[str(T/'helios-util'),'bls','create','key','--to-console']if role=='bls'else[str(T/'cleos'),'create','key','--to-console']
    out=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=30).stdout
    fresh[n][role]={line.split(':',1)[0].strip():line.split(':',1)[1].strip()for line in out.splitlines()if ':'in line}
  keyfile.write_text(json.dumps(fresh,indent=2)+'\n');keyfile.chmod(0o600)
 fresh=json.loads(keyfile.read_text());SECRETS.extend(v['Private key']for k in fresh.values()for v in k.values())
 for n in NAMES:
  k=fresh[n]
  tx=transaction('postban-key-rotation-'+n,[action('eosio','regfinkey',n,{'finalizer_name':n,'finalizer_key':k['bls']['Public key'],'proof_of_possession':k['bls']['Proof of Possession']}),action('eosio','actfinkey',n,{'finalizer_name':n,'finalizer_key':k['bls']['Public key']}),action('eosio','regpeerkey',n,{'proposer_finalizer_name':n,'key':k['peer']['Public key']})])
  c=one('rotcands',n);b=one('bpbonds',n);check(n+' valid finalizer/peer key changes cannot clear ban or restore queue',c['banned']and c['zero_windows']==3 and int(c['ticket'])==0 and b['state']==4 and int(b['settled'])==100000000,transaction=tx,new_peer_public_key=k['peer']['Public key'],new_finalizer_public_key=k['bls']['Public key'])
 # Exercise a normal standby maintenance enter/resume after blacklisting.
 # The service keeps running throughout; no healthy producer is stopped.
 snap=snapshot();duties=set(snap['producer_names'])|set(snap['finalizer_names'])|set(snap['rotation']['active'])|set(snap['rotation']['target'])
 choices=[v for v in table('rotcands')if v['owner']in healthy and v['owner']not in duties]
 normal=max(choices,key=lambda v:int(v['ticket']))['owner'];normal_key=json.loads((B/'private-keys.json').read_text())[normal]['account']['Private key'];SECRETS.append(normal_key);cli(['wallet','import','-n','founder-demo'],normal_key+'\n',allow=True)
 normal_bond=one('bpbonds',normal);normal_candidate=one('rotcands',normal)
 tx=transaction('postban-healthy-maintenance-enter',[action('eosio','setmaint',normal,{'producer':normal,'maintenance':True})]);end=time.monotonic()+1800
 while True:
  m=one('bpmaint',normal)
  if m['state']==2 and int(m['effective_block'])<=rpc('get_info')['last_irreversible_block_num']:break
  assert time.monotonic()<end,'Healthy maintenance handoff did not finish';time.sleep(2)
 check('healthy standby enters irreversible maintenance without bond loss',one('bpbonds',normal)==normal_bond and not one('rotcands',normal)['banned'],producer=normal,transaction=tx,maintenance=m)
 def maintenance_summary():return json.load(urllib.request.urlopen(urllib.request.Request('https://purehistory-api.matrixai.one/v2/state/get_producer_summary',headers={'User-Agent':'Mozilla/5.0'}),timeout=30))
 end=time.monotonic()+180
 while True:
  summary=maintenance_summary()
  if summary.get('maintenance_active_count')==1 and summary.get('eligible_bp_count')==39:break
  assert time.monotonic()<end,'Maintenance counts did not catch up';time.sleep(2)
 check('maintenance counters and eligible BP total reflect actual paused state',summary['registered_bp_count']==45 and summary['permanent_blacklist_count']==5,summary=summary)
 tx=transaction('postban-healthy-maintenance-resume',[action('eosio','setmaint',normal,{'producer':normal,'maintenance':False})]);m=one('bpmaint',normal)
 check('healthy maintenance resume preserves bond and penalty record',m['state']==0 and one('bpbonds',normal)==normal_bond and one('rotcands',normal)['zero_windows']==normal_candidate['zero_windows'],producer=normal,transaction=tx,maintenance=m)
 end=time.monotonic()+180
 while True:
  summary=maintenance_summary()
  if summary.get('maintenance_active_count')==summary.get('maintenance_pending_count')==0 and summary.get('eligible_bp_count')==40:break
  assert time.monotonic()<end,'Resume counts did not catch up';time.sleep(2)
 check('maintenance counters return to zero and eligible count40',summary['permanent_blacklist_count']==5,summary=summary)


 detailed=json.loads(cli(['push','action','eosio','getpeerkeys','{}','-p',actor+'@active','-j']).stdout)
 write('NATIVE_DISCOVERY_QUERY_RESPONSE.json',detailed)
 traces=detailed['processed']['action_traces'];value=traces[0].get('return_value_data')
 if isinstance(value,str):value=json.loads(value)
 assert isinstance(value,list),'Native discovery action return JSON not decoded; preserve detailed receipt for inspection'
 discovery_names={v['producer_name']for v in value}
 check('native peer-key discovery excludes all banned identities even after key changes',discovery_names==healthy and not discovery_names&set(NAMES),returned_producers=sorted(discovery_names))
 end=time.monotonic()+180;tid=detailed['transaction_id'];height=int(detailed['processed']['block_num'])
 while rpc('get_info')['last_irreversible_block_num']<height:assert time.monotonic()<end;time.sleep(.2)
 canonical=rpc('get_block',{'block_num_or_id':height});assert any((v['trx']if isinstance(v['trx'],str)else v['trx']['id'])==tid for v in canonical['transactions'])
 write('NATIVE_DISCOVERY_AFTER_BLACKLIST.json',{'status':'PASS','UTC':now(),'returned':value,'transaction_id':tid,'height':height,'block_id':canonical['id'],'processed_trace':detailed['processed']})
 def connection_check(entry):
  idx=entry['index'];port=8888 if idx==0 else 12000+idx
  data=json.load(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+str(port)+'/v1/net/connections',b'{}',{'Content-Type':'application/json'}),timeout=30))
  signed=[v for v in data if v.get('is_bp_gossip_peer')and v.get('is_socket_open')]
  assert signed,entry['name']+' has no signed open peer after blacklist'
  return {'producer':entry['name'],'signed_open_connections':len(signed),'peers':[v.get('peer')for v in signed]}
 with ThreadPoolExecutor(max_workers=6)as pool:connections=list(pool.map(connection_check,BASE_PLAN['nodes']))
 check('all40 healthy nodes retain signed open BP discovery connections',len(connections)==40)
 write('SIGNED_DISCOVERY_AFTER_BLACKLIST.json',{'status':'PASS','UTC':now(),'nodes':connections})
 after_producers={v['owner']:v for v in table('producersv2')};check('historical earned unpaid rewards unchanged by bans and rejected claims',all(int(after_producers[n]['unpaid_blocks'])==int(before_producers[n]['unpaid_blocks'])>0 and after_producers[n]['last_claim_time']==before_producers[n]['last_claim_time']for n in NAMES))
 token=rpc('get_currency_stats',{'code':'eosio.token','symbol':'AIC'})['AIC'];check('no mint or burn during forfeiture and settlement',token['supply']=='100000000.0000 AIC'and token['max_supply']=='2100000000.0000 AIC')
 check('qualified runtime contract and parameters preserved',rpc('get_code_hash',{'account_name':'eosio'})['code_hash']=='b591ca661e8256b7d1c7370fe11e5825427c98b4f84eceb3cdf735c06e5e8170'and all(rpc('get_consensus_parameters')['chain_config'][k]==v for k,v in json.loads((B/'chain-parameters.json').read_text()).items())and table('global2')[0]['new_ram_per_block']==1024)
 gov=rpc('get_upgrade_state');pre=json.loads((E/'PRE_ADD_BASELINE.json').read_text())['upgrade'];check('seven-day governance protections unchanged',gov['review_seconds']==604800 and gov['developer']==pre['developer']and gov['protected_accounts']==pre['protected_accounts'])
 authorities={}
 for pool in ['eosio.bond','eosio.bslash']:
  a=rpc('get_account',{'account_name':pool});owner=next(v['required_auth']for v in a['permissions']if v['perm_name']=='owner');active=next(v['required_auth']for v in a['permissions']if v['perm_name']=='active');allowed={('eosio','eosio.code'),(pool,'eosio.code')}
  check(pool+' protected custody authority and empty code preserved',owner=={'threshold':1,'keys':[],'accounts':[],'waits':[]}and active['threshold']==1 and not active['keys']and not active['waits']and {(v['permission']['actor'],v['permission']['permission'])for v in active['accounts']}==allowed and rpc('get_code_hash',{'account_name':pool})['code_hash']=='0'*64);authorities[pool]=a
 health=healthy_all();write('POST_FAULT_HEALTH.json',health);before=rpc('get_info');time.sleep(10);after=rpc('get_info');check('head and irreversible progress continue after backfill',after['head_block_num']>before['head_block_num']and after['last_irreversible_block_num']>before['last_irreversible_block_num'])
 def public(url):return json.load(urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Origin':'https://aic.matrixai.one'}),timeout=30))
 end=time.monotonic()+300
 while True:
  summary=public('https://purehistory-api.matrixai.one/v2/state/get_producer_summary')
  if summary.get('available')and summary.get('registered_bp_count')==45 and summary.get('eligible_bp_count')==40:break
  assert time.monotonic()<end,'Public summary did not catch up';time.sleep(3)
 check('public summary reports45 registered40 eligible',summary['chain_id']==CHAIN)
 rotations=public('https://purehistory-api.matrixai.one/v2/history/get_rotations?limit=20');check('rotation history remains canonical irreversible',rotations['chain_id']==CHAIN and all(v['finalized']and rpc('get_block',{'block_num_or_id':v['height']})['id']==v['block_id']for v in rotations['events']))
 history_txs=[]
 for n in NAMES:
  tx=R['transactions']['postban-permissionless-settlement-'+n];end=time.monotonic()+300
  while True:
   try:
    h=public('https://purehistory-api.matrixai.one/v2/history/get_transaction?id='+tx['id']);assert h['executed']and h['trx_id']==tx['id']and h['actions']and all(int(a['block_num'])==tx['height']and a['block_id']==tx['block_id']and a['trx_id']==tx['id']for a in h['actions']);assert any(a['act']['account']=='eosio.token'and a['act']['name']=='transfer'and a['act']['data']['from']=='eosio.bond'and a['act']['data']['to']=='eosio.bslash'and a['act']['data']['quantity']=='10000.0000 AIC'for a in h['actions']);break
   except Exception:
    assert time.monotonic()<end,'History settlement lookup failed';time.sleep(3)
  history_txs.append({'owner':n,'transaction':tx,'history':h})
 check('all five settlement transactions indexed at canonical block',len(history_txs)==5)
 voting=json.loads((E/'voting/RESULT.json').read_text());actual_votes={p['owner']:int(p['total_votes'])for p in table('producersv2')}
 check('all45 randomized vote totals remain distinct and unchanged after bans',actual_votes==voting['vote_totals_smallest_units']and len(set(actual_votes.values()))==45)
 with ThreadPoolExecutor(max_workers=6)as pool:self_rows=dict(zip(actual_votes,pool.map(lambda n:one('votersv2',n),actual_votes)))
 check('all45 BP self votes remain intact after blacklist and maintenance',all(v['producers']==[n]and not v['proxy']and int(v['last_vote_amount'])>0 for n,v in self_rows.items()))
 expected_users=voting['all_ordinary_voters']
 with ThreadPoolExecutor(max_workers=6)as pool:ordinary_rows=dict(zip(expected_users,pool.map(lambda n:one('votersv2',n),expected_users)))
 check('all90 ordinary randomized choices and integer weights remain intact',all(v['producers']==expected_users[n]['producers']and int(v['last_vote_amount'])==int(expected_users[n]['last_vote_amount'])for n,v in ordinary_rows.items()))
 activity=json.loads((E/'activity/STATE.json').read_text());check('ordinary transfer and contract activity continued through five-node fault',activity['status']=='RUNNING'and activity['business_transactions']>activity_before and activity['ticks']>0 and activity['notes']>0 and activity['empty_blocks']>0 and all(1<=int(n)<=20 for n in activity['batch_sizes']),before_business_transactions=activity_before,after_business_transactions=activity['business_transactions'])
 samples={}
 for file in sorted((E/'activity/batches').glob('*.jsonl'),reverse=True):
  for line in reversed(file.read_text().splitlines()):
   batch=json.loads(line)
   for tx in batch['transactions']:
    kind=tx['metadata']['kind']
    if kind not in samples:samples[kind]={'transaction':tx,'receipt':batch['receipts'][tx['id']]}
   if len(samples)==3:break
  if len(samples)==3:break
 check('canonical ordinary activity includes transfers and both contract actions',set(samples)=={'transfer','tick','note'})
 for kind,sample in samples.items():
  tid=sample['transaction']['id'];receipt=sample['receipt'];end=time.monotonic()+300
  while True:
   try:
    h=public('https://purehistory-api.matrixai.one/v2/history/get_transaction?id='+tid);assert h['executed']and h['trx_id']==tid and h['actions']and all(int(a['block_num'])==receipt['height']and a['block_id']==receipt['id']for a in h['actions']);assert any(a['act']['account']==('eosio.token'if kind=='transfer'else'civiccounter')and a['act']['name']==kind for a in h['actions']);break
   except Exception:
    assert time.monotonic()<end,'Ordinary activity not indexed';time.sleep(2)
  sample['history']=h
 check('public history decodes actual ordinary transfers/tick/note at canonical blocks',len(samples)==3)
 write('POST_BAN_VOTES_AND_ACTIVITY.json',{'status':'PASS','UTC':now(),'all45_votes_unchanged':True,'all45_self_votes_intact':True,'ordinary_voters':90,'activity':{k:activity[k]for k in ['status','completed_batches','business_transactions','transfers','ticks','notes','empty_blocks','batch_sizes','max_chain_receipts_in_observed_batch_block']},'canonical_business_history_samples':samples})

 processes=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   args=(p/'cmdline').read_bytes().decode(errors='replace').split('\0')
   if any(a.endswith('/nodeos')for a in args):processes.append(int(p.name))
  except(FileNotFoundError,PermissionError,ProcessLookupError):pass
 check('final40 onlineBP plus1 nonproducing history process',len(processes)==41 and all(subprocess.run(['systemctl','is-active','--quiet','pureeos-bond-bp-'+n+'-20261102.service']).returncode!=0 for n in NAMES))
 end=time.monotonic()+180
 while True:
  final_snapshot=snapshot()
  if set(final_snapshot['producer_names'])==set(final_snapshot['finalizer_names'])and len(final_snapshot['producer_names'])==21 and not(set(NAMES)&set(final_snapshot['producer_names']))and final_snapshot['finalizers']['active_finalizer_policy']['threshold']==15:break
  assert time.monotonic()<end,'No coherent healthy final policy snapshot';time.sleep(1)
 result={'status':'PASS','UTC':now(),'chain_id':CHAIN,'scope':'Same physical host; five genuine offline BPs, canonical irreversible permanent bans, bond forfeiture and post-ban functional checks. No new TPS, no wall-seven-day claim. Native22case qualification separately retained.','checks':CHECKS,'names':NAMES,'bond_configuration':cfg,'escrow':'400000.0000 AIC','forfeiture_pool':'50000.0000 AIC','bonds':table('bpbonds'),'blacklist_evidence':evidence,'all_candidates':table('rotcands'),'final_native_snapshot':final_snapshot,'healthy_nodes':health,'final_nodeos_processes':processes,'token':token,'custody_authorities':authorities,'governance':gov,'public_summary':summary,'public_rotations':rotations,'history_transactions':history_txs,'before':before,'after':after,'transactions':R['transactions']}
 write('FINAL_RESULT.json',result);status('PASS_FIVE_REAL_BANS_AND_POST_BLACKLIST_FUNCTIONS',check_count=len(CHECKS),registered=45,eligible=40,banned=NAMES,online_BP=40,history=1,pool='50000.0000 AIC')
except BaseException:
 status('POSTCHECK_FAIL',error=traceback.format_exc());raise
finally:
 subprocess.run(['systemctl','stop','pureeos-bond-join-wallet-20261102.service'],capture_output=True,timeout=30)
