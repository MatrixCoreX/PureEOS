# PureEOS system contracts 1.0.0

Exact qualified WASM373b66 / packedABI038ffb with corresponding committed source15dea. Preserve all selected modes. Fresh genesis initializes RAM64GiB, setramrate1024 and native feature PUREEOS_SEVEN_DAY_GOVERNANCE. Existing sealed chains use normal developer review; this package does not bypass governance.

Compile the included source with PureEOS CDT and PUREEOS_SINGLE_CHOICE_VOTING, PUREEOS_SEQUENTIAL_ROTATION, PUREEOS_RESOURCE_SPLIT, PUREEOS_UPGRADE_GOVERNANCE, PUREEOS_BP_PEERING and PUREEOS_BP_MAINTENANCE enabled. Use the package manifest to verify exact qualified bytes. See the matching PureEOS baseline/operator guides for initialization and feature activation.
